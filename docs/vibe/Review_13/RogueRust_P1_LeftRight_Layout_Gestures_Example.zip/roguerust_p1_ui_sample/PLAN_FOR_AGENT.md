# 交给本地 Agent 的限定执行计划

**授权范围**：仅在 `web-next` P1 示例内验证与移植；不得修改 Rust/WASM、全量门禁、V2 规则、游戏资源文件或其他 UI 代码。严格保持 P1 Mock 默认局面，允许 `?debug&enemies=N` 测试队形。

## 核查顺序

1. 检查仓库当前 commit 与 `bf7c7f5` 是否存在冲突；不要覆盖已有同等功能。
2. 在干净 worktree 运行 `apply_p1_ui_example.py .`，检查全部 anchor；通过后才 `--apply`。
3. 运行 `npm run build`、纯函数测试、既有第 25 道门禁；如果失败，提交具体报错与日志，不得声称通过。
4. 1280×800 与 390×844 分别测试 `?debug&enemies=1/3/5/6`，检查 formation 与 hit overlay 是否一致。
5. 用真实 CDP `Input.dispatchMouseEvent`、`Input.dispatchTouchEvent` 覆盖重复点击、长按、移动取消、二指、无目标落到敌人上。
6. 只修正定向暴露的问题，不引入新的手势库或渲染系统；显式标注残余风险。

## 退出条件

- 左右阵营、横屏两行、竖屏单列正确，槽位身份稳定。
- Pointer Events + 状态机无重复提交、无幽灵提交、无“合法动作却回弹”。
- 详情能通过真实用户操作打开/关闭；指针反馈不会遮挡目标或吞命中。
- 修改范围与以上授权严格一致；报告将 **实际通过、静态推断、未验证** 区分开。
