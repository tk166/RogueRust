// 纯数学测试，不需要 WebGL。执行：详见 README。
import assert from 'node:assert/strict';
import { computeCombatFormation } from '../tmp-test-build/stage/formation.js';
const portrait = { width: 390, height: 844, halfW: 1.82, halfH: 3.93 };
const desktop = { width: 1280, height: 800, halfW: 3.98, halfH: 2.49 };
for (let n = 0; n <= 6; n++) {
  const slots = Array.from({length:n}, (_,i)=>i+10);
  const p = computeCombatFormation(slots,portrait);
  const d = computeCombatFormation(slots,desktop);
  assert.equal(p.enemies.length,n);
  assert.equal(d.enemies.length,n);
  assert.deepEqual(p.enemies.map(x=>x.slot), slots);
  assert.ok(p.enemies.every(x=>x.x>0 && x.row===0));
  assert.ok(d.enemies.every(x=>x.x>0));
  assert.equal(new Set(d.enemies.filter(x=>x.row===0).map(x=>x.slot)).size,Math.ceil(n/2));
  assert.equal(new Set(d.enemies.filter(x=>x.row===1).map(x=>x.slot)).size,Math.floor(n/2));
  assert.ok(p.hero.x<0 && d.hero.x<0);
  assert.ok(p.enemies.every(x=>x.y> -portrait.halfH*.5 && x.y<portrait.halfH*.7));
}
assert.throws(()=>computeCombatFormation(Array.from({length:7},(_,i)=>i),desktop),/at most 6/);
assert.throws(()=>computeCombatFormation([1,1],desktop),/unique/);
console.log('formation pure tests passed');
