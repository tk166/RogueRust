import assert from 'node:assert/strict';
import { INITIAL, reduce } from '../tmp-test-build/pointerMachine.js';
const options=[{slot:2,actionIndex:77,label:'attack'}];
function act(s){s=reduce(s,{type:'down',handSlot:0,options});s=reduce(s,{type:'move',hoverSlot:2,distance:35});return reduce(s,{type:'up',hoverSlot:2,distance:35});}
const a=act(INITIAL);const b=act(a);
assert.equal(a.lastResult.kind,'commit');assert.equal(b.lastResult.kind,'commit');
assert.equal(b.resultSeq,a.resultSeq+1);
let c=reduce(INITIAL,{type:'down',handSlot:3,options:[{slot:-1,actionIndex:99,label:'defend'}]});
c=reduce(c,{type:'move',hoverSlot:1,distance:40});c=reduce(c,{type:'up',hoverSlot:1,distance:40});
assert.deepEqual(c.lastResult,{kind:'commit',handSlot:3,actionIndex:99,targetSlot:-1});
let d=reduce(INITIAL,{type:'down',handSlot:0,options});
d=reduce(d,{type:'dismiss'});assert.equal(d.phase,'idle');assert.equal(d.lastResult,null);
console.log('pointerMachine targeted / untargeted / replay / dismiss tests passed');
