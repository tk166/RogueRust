#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then echo 'Usage: bash scripts/run-pure-tests.sh /path/to/RogueRust'; exit 2; fi
REPO="$(cd "$1" && pwd)"
BASE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$BASE"
rm -rf tmp-test-src tmp-test-build
mkdir -p tmp-test-src/stage tmp-test-src/input
cp files/formation.ts tmp-test-src/stage/
cp files/hitTest.ts tmp-test-src/input/
cp "$REPO/web-next/src/input/pointerMachine.ts" tmp-test-src/pointerMachine.ts
cat > tmp-test-src/stage/layout.ts <<'TS'
// Type-only stand-in for isolated tests. Real source resides in web-next/src/stage/layout.ts.
export interface EnemyScreen { slot:number; x:number; y:number; r:number }
export interface CardScreen { slot:number; x:number; y:number; w:number; h:number; visibleW:number; hitX:number; hitY:number; lifted:boolean }
TS
TSC="$REPO/web-next/node_modules/.bin/tsc"
if [[ ! -x "$TSC" ]]; then TSC="$(command -v tsc || true)"; fi
if [[ -z "$TSC" ]]; then echo 'TypeScript compiler not installed. Run npm ci inside web-next.' >&2; exit 2; fi
"$TSC" --target es2022 --module es2022 --moduleResolution node --skipLibCheck \
  --rootDir tmp-test-src --outDir tmp-test-build \
  tmp-test-src/stage/formation.ts tmp-test-src/input/hitTest.ts tmp-test-src/pointerMachine.ts
node tests/formation.test.mjs
node tests/hitTest.test.mjs
node tests/pointerMachine.test.mjs
rm -rf tmp-test-src tmp-test-build
echo 'Pure-function checks PASS (this is NOT a browser or full TS/R3F build).'
