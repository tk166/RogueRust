#!/usr/bin/env python3
"""Safely apply the illustrated P1 UI changes to a checkout based on bf7c7f5.

DEFAULT IS --check (no writes). --apply only if every source anchor matches exactly.
Deliberately does not run git commands or modify Rust/WASM, package metadata, or old web/.
"""
from __future__ import annotations
import argparse
import difflib
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
TARGET = "web-next/src"


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise ValueError(f"{label}: expected exactly one matching block, found {count}; "
                         "source version may differ. Nothing was written.")
    return text.replace(old, new, 1)


def patch_pointer(src: str) -> str:
    src = replace_once(src,
        '  readonly lastResult: Result | null;\n}',
        '  readonly lastResult: Result | null;\n'
        '  /** [P1-UX] 每产生一次结果都增加。相同 payload 的两次出牌不是同一事件。 */\n'
        '  readonly resultSeq: number;\n}', 'pointer.State')
    src = replace_once(src,
        '  | { readonly type: "cancel" };',
        '  | { readonly type: "cancel" }\n'
        '  /** [P1-UX] 长按打开详情后安静退出，不记录一次假的回弹。 */\n'
        '  | { readonly type: "dismiss" };', 'pointer.Event')
    src = replace_once(src,
        '  lastResult: null,\n};',
        '  lastResult: null,\n  resultSeq: 0,\n};', 'pointer.INITIAL')
    src = replace_once(src,
        '        lastResult: null,\n      };',
        '        lastResult: null,\n        resultSeq: state.resultSeq,\n      };', 'pointer.down')
    src = replace_once(src,
        '    case "cancel":\n      return state.phase === "idle"\n        ? state\n        : { ...INITIAL, lastResult: { kind: "rebound", handSlot: state.handSlot, why: "illegal-target" } };',
        '    case "cancel":\n      return state.phase === "idle"\n        ? state\n        : { ...INITIAL, resultSeq: state.resultSeq + 1,\n            lastResult: { kind: "rebound", handSlot: state.handSlot, why: "illegal-target" } };\n'
        '    case "dismiss":\n      // [P1-UX] 长按详情和游戏逻辑互斥，松手不能再派发 Commit。\n'
        '      return { ...INITIAL, resultSeq: state.resultSeq };', 'pointer.cancel')
    src = replace_once(src,
        '  const chosen = state.options.find((option) => option.slot === targetSlot);\n',
        '  // [P1-UX] 无目标牌的业务落点永远是 -1。真实屏幕上松在敌人/空白处都不改变动作。\n'
        '  const chosen = needsTarget(state.options)\n'
        '    ? state.options.find((option) => option.slot === targetSlot)\n'
        '    : state.options.find((option) => option.slot === -1);\n', 'pointer.finish.choice')
    src = replace_once(src,
        '? { kind: "commit", handSlot: state.handSlot, actionIndex: chosen.actionIndex, targetSlot }',
        '? { kind: "commit", handSlot: state.handSlot, actionIndex: chosen.actionIndex, targetSlot: chosen.slot }',
        'pointer.finish.target')
    src = replace_once(src,
        '  return { ...INITIAL, lastResult };',
        '  // [P1-UX] 事件编号只在真实 commit/rebound 时前进，解决相同操作吞掉第二次的问题。\n'
        '  return { ...INITIAL, resultSeq: state.resultSeq + 1, lastResult };', 'pointer.finish.result')
    return src


def patch_stage(src: str) -> str:
    src = replace_once(src,
        'import { useMemo, useRef } from "react";',
        'import { useEffect, useMemo, useRef } from "react";',
        'Stage.import.effect')
    src = replace_once(src,
        'import { layout, type CardScreen, type EnemyScreen } from "./layout";',
        'import { layout, type CardScreen, type EnemyScreen } from "./layout";\n'
        'import { computeCombatFormation } from "./formation";\n'
        'import type { Phase } from "../input/pointerMachine";', 'Stage.import')
    src = replace_once(src,
        '''  hoverSlot: number;
  onCardDown: (slot: number) => void;
  onHover: (slot: number) => void;
  onRelease: (slot: number) => void;
}
export function Stage({ scene, liftedSlot, hoverSlot, onCardDown, onHover, onRelease }: StageProps) {''',
        '''  hoverSlot: number;
  /** [P1-UX] 视觉上悬停与业务上的目标选择是两种正交状态。 */
  hoverCardSlot: number;
  hoveredEnemySlot: number;
  phase: Phase;
  followPointer: boolean;
  legalTargets: readonly number[];
  onCardDown: (slot: number, pointer: { id: number; type: string; x: number; y: number }) => void;
  onCardHover: (slot: number) => void;
  onHover: (slot: number) => void;
  onRelease: (slot: number) => void;
}
export function Stage({
  scene, liftedSlot, hoverSlot, hoverCardSlot, hoveredEnemySlot, phase, followPointer,
  legalTargets, onCardDown, onCardHover, onHover, onRelease,
}: StageProps) {''', 'Stage.props')
    src = replace_once(src,
        '  useFrame(({ clock }) => {',
        """  // [P1-UX] 瞄准连线只有 2 个顶点；每帧改 BufferAttribute，不创建新 Mesh/React 节点。
  // 线只是演出，不参与射线，不改变 WASM 的目标选择与命中判定。
  const aimLine = useMemo(() => {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.BufferAttribute(new Float32Array(6), 3));
    const material = new THREE.LineBasicMaterial({
      color: "#8dffcb", transparent: true, opacity: 0.90,
      depthTest: false, depthWrite: false,
    });
    const beam = new THREE.Line(geometry, material);
    beam.renderOrder = 19;
    beam.frustumCulled = false;
    beam.visible = false;
    beam.raycast = () => {}; // 从不遮挡敌人或手牌射线。
    return beam;
  }, []);
  useEffect(() => () => {
    aimLine.geometry.dispose();
    (aimLine.material as THREE.Material).dispose();
  }, [aimLine]);

  useFrame(({ clock }, delta) => {""", 'Stage.aimLine')
    src = replace_once(src,
        '''    // ── 呼吸：证明这是活的 3D 场景 ─────────────────────────────────────────
    const groundY = -halfH * 0.5;
    if (groundRef.current) groundRef.current.position.y = groundY;
    if (heroRef.current) {
      heroRef.current.position.set(0, -halfH * 0.3 + 0.02 * Math.sin(t * 1.6), 0.15);
    }
    const enemyX = Math.min(1.35, halfW * 0.6);
    const enemyY = -halfH * 0.05;
    for (const [index, group] of enemyRefs.current.entries()) {
      if (!group) continue;
      group.position.set(
        (index === 0 ? -1 : 1) * enemyX,
        enemyY + 0.03 * Math.sin(t * 1.3 + index * 1.7),
        -0.4
      );
    }''',
        '''    // [P1-LAYOUT] 队形由纯函数统一计算。以后接真实 WASM 时替换数据源即可；
    // 战场仍然是 "我方在左、敌人在右"，竖屏右侧单列，横屏右侧两行（每行至多三名）。
    const formation = computeCombatFormation(
      scene.enemies.map((enemy) => enemy.slot),
      { width: size.width, height: size.height, halfW, halfH }
    );
    const groundY = -halfH * 0.5;
    if (groundRef.current) groundRef.current.position.y = groundY;
    if (heroRef.current) {
      heroRef.current.position.set(
        formation.hero.x, formation.hero.y + 0.025 * Math.sin(t * 1.6), formation.hero.z
      );
    }
    for (const [index, group] of enemyRefs.current.entries()) {
      const place = formation.enemies[index];
      if (!group || !place) continue;
      group.position.set(place.x, place.y + 0.025 * Math.sin(t * 1.3 + index * 1.7), place.z);
      group.scale.setScalar(place.scale);
    }''', 'Stage.formation')
    src = replace_once(src,
        '''      const lifted = index === liftedSlot;
      const targetX = lifted ? scratch.pointerWorld.x : local.x;
      const targetY = lifted ? scratch.pointerWorld.y - 0.1 : local.y;
      const targetZ = lifted ? LIFT_Z : local.z;
      const targetAngle = lifted ? 0 : local.angle;
      const targetScale = lifted ? 1.32 : 1;
      // 指数趋近：既跟随又不会抖动。抬起的牌跟得快，回落跟得慢一点（回弹手感）。
      // `still` 下直接吸附（k = 1）：截图不该拍到"恰好走到一半"的位置。
      const k = still ? 1 : lifted ? 0.45 : 0.3;''',
        '''      const lifted = index === liftedSlot;
      const hovered = index === hoverCardSlot && phase === "idle";
      // [P1-UX] 鼠标悬停轻抬；按下/拖拽显著抬起；点按目标牌后，预览固定在战场偏左下，
      // 不会在松开手指后继续粘着上一指针位置，从而挡住右侧敌人。
      const previewX = formation.portrait ? -halfW * 0.16 : -halfW * 0.22;
      const previewY = -halfH * 0.28;
      const targetX = lifted ? (followPointer ? scratch.pointerWorld.x : previewX) : local.x;
      const targetY = lifted ? (followPointer ? scratch.pointerWorld.y - 0.1 : previewY)
        : local.y + (hovered ? 0.11 : 0);
      const targetZ = lifted ? LIFT_Z : hovered ? 1.32 : local.z;
      const targetAngle = lifted ? 0 : local.angle;
      const targetScale = lifted ? 1.32 : hovered ? 1.11 : 1;
      // [P1-UX] 用 deltaTime 而非每帧固定系数，避免 30 / 60 / 120 Hz 手感不同。
      const k = still ? 1 : 1 - Math.exp(-(lifted ? 22 : hovered ? 16 : 13) * Math.min(delta, 0.1));''', 'Stage.card.motion')
    src = replace_once(src,
        'card.visibleW = card.lifted ? card.w : Math.min(card.w, Math.max(stride, 1));',
        'card.visibleW = (card.lifted || card.slot === hoverCardSlot) ? card.w : Math.min(card.w, Math.max(stride, 1));',
        'Stage.card.visible')
    src = replace_once(src,
        'scratch.offset.set(0.44, 0, 0);',
        'scratch.offset.set(0.44 * (formation.enemies[index]?.scale ?? 1), 0, 0);',
        'Stage.enemy.radius')
    src = replace_once(src,
        '    layout.frames += 1;',
        """    // [P1-UX] 只在 "目标合法且真的被指向" 时画瞄准线，避免误导玩家。
    const aimTarget = formation.enemies.find((p) => p.slot === hoverSlot);
    const aimCard = liftedSlot >= 0 ? cardRefs.current[liftedSlot] : null;
    const aimActive = phase === "targeting" && legalTargets.includes(hoverSlot) && !!aimTarget && !!aimCard;
    aimLine.visible = aimActive;
    if (aimActive && aimTarget && aimCard) {
      const pos = aimLine.geometry.getAttribute("position") as THREE.BufferAttribute;
      pos.setXYZ(0, aimCard.position.x, aimCard.position.y, 1.7);
      pos.setXYZ(1, aimTarget.x, aimTarget.y, 0.52);
      pos.needsUpdate = true;
    }
    layout.frames += 1;""", 'Stage.aimFrame')
    src = replace_once(src,
        '''        const targeted = hoverSlot === enemy.slot;
        return (
          <group
            key={enemy.id}''',
        '''        // [P1-UX] "可选目标"与"已命中目标"分别提示；死亡/非法目标不显示绿色。
        const eligible = phase === "targeting" && legalTargets.includes(enemy.slot) && !dead;
        const targeted = eligible && hoverSlot === enemy.slot;
        const hovered = hoveredEnemySlot === enemy.slot;
        const illegalHover = phase === "targeting" && hovered && !eligible && !dead;
        return (
          <group
            key={`${enemy.id}-${enemy.slot}`}''', 'Stage.enemy.feedback')
    src = replace_once(src,
        '''            onPointerMove={(event) => {
              event.stopPropagation();
              onHover(enemy.slot);
            }}
            onPointerUp={(event) => {''',
        '''            onPointerMove={(event) => {
              event.stopPropagation();
              onHover(enemy.slot);
            }}
            onPointerOut={() => onHover(-1)}
            onPointerUp={(event) => {''', 'Stage.enemy.pointerOut')
    src = replace_once(src,'{index === 0 ? (','{index % 2 === 0 ? (','Stage.enemy.shape')
    src = replace_once(src,
        'color={dead ? "#2b3239" : targeted ? "#7ddc8a" : "#4c9a5a"}',
        'color={dead ? "#2b3239" : targeted ? "#7ddc8a" : hovered ? "#78c786" : "#4c9a5a"}',
        'Stage.enemy.material1')
    src = replace_once(src,
        'color={dead ? "#2b3239" : targeted ? "#e0b46a" : "#9c6b3c"}',
        'color={dead ? "#2b3239" : targeted ? "#e0b46a" : hovered ? "#c89b63" : "#9c6b3c"}',
        'Stage.enemy.material2')
    src = replace_once(src,
        '''            {/* 合法目标高亮：脚下一圈 */}
            {targeted && (
              <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.5, 0]}>
                <ringGeometry args={[0.5, 0.62, 24]} />
                <meshBasicMaterial color="#9dff9d" transparent opacity={0.75} side={THREE.DoubleSide} />
              </mesh>
            )}''',
        '''            {/* [P1-UX] 用面向相机的轮廓环替代水平地面环：竖屏/固定镜头也明显可见。
                青色=可选，绿色=当前有效目标；这只是 UI 提示，动作合法性仍由 options 决定。 */}
            {(eligible || illegalHover) && (
              <mesh position={[0, 0, 0.40]} raycast={() => null}>
                <ringGeometry args={[0.49, 0.55, 36]} />
                <meshBasicMaterial
                  color={illegalHover ? "#ff917b" : targeted ? "#86ffba" : "#7cc9ff"}
                  transparent opacity={illegalHover || targeted ? 0.96 : 0.55}
                  side={THREE.DoubleSide} depthTest={false} depthWrite={false}
                />
              </mesh>
            )}''', 'Stage.enemy.ring')
    src = replace_once(src,
        '''          onPointerDown={(event) => {
            event.stopPropagation();
            onCardDown(index);
          }}''',
        '''          onPointerOver={(event) => {
            if (event.pointerType === "mouse" || event.pointerType === "pen") onCardHover(index);
          }}
          onPointerOut={() => onCardHover(-1)}
          onPointerDown={(event) => {
            if (event.button !== 0) return; // 右键用于查看详情，不应进入出牌状态。
            event.stopPropagation();
            // [P1-UX] 保留 pointerId + CSS 像素原点供全局监听器计算真实拖动距离。
            onCardDown(index, {
              id: event.pointerId, type: event.pointerType,
              x: event.clientX, y: event.clientY,
            });
          }}''', 'Stage.card.pointer')
    src = replace_once(src,
        '      <color attach="background" args={["#0b0f14"]} />',
        '      <color attach="background" args={["#0b0f14"]} />\n'
        '      {/* [P1-UX] 瞄准连线共享整个场景的坐标系，目标被遮挡也不会错误发动作。 */}\n'
        '      <primitive object={aimLine} />',
        'Stage.aimPrimitive')
    return src


def patch_overlay(src: str) -> str:
    src = replace_once(src,
        '  liftedSlot: number;\n',
        '  liftedSlot: number;\n  /** [P1-UX] 仅桌面 hover；触屏通过按压/长按进入大卡预览。 */\n  hoverCardSlot: number;\n',
        'TextOverlay.props')
    src = replace_once(src,
        'export function TextOverlay({ scene, liftedSlot, detailSlot, modalOpen }: TextOverlayProps) {',
        'export function TextOverlay({ scene, liftedSlot, hoverCardSlot, detailSlot, modalOpen }: TextOverlayProps) {',
        'TextOverlay.function')
    src = replace_once(src,
        '        const selected = index === liftedSlot;',
        '        const selected = index === liftedSlot;\n        const hovered = index === hoverCardSlot;',
        'TextOverlay.hovered')
    src = replace_once(src,
        'className={`card-text${selected ? " is-selected" : ""}`}',
        'className={`card-text${selected ? " is-selected" : ""}${hovered ? " is-hovered" : ""}`}',
        'TextOverlay.class')
    src = replace_once(src,
        '  modalOpen: boolean;\n}',
        '  modalOpen: boolean;\n  /** [P1-UX] 详情可通过可见按钮关闭。 */\n  onCloseDetail: () => void;\n}',
        'TextOverlay.closeProps')
    src = replace_once(src,
        'export function TextOverlay({ scene, liftedSlot, hoverCardSlot, detailSlot, modalOpen }: TextOverlayProps) {',
        'export function TextOverlay({ scene, liftedSlot, hoverCardSlot, detailSlot, modalOpen, onCloseDetail }: TextOverlayProps) {',
        'TextOverlay.closeSignature')
    src = replace_once(src,
        '{detailSlot >= 0 && <DetailCard card={scene.hand[detailSlot]} />}',
        '{detailSlot >= 0 && <DetailCard card={scene.hand[detailSlot]} onClose={onCloseDetail} />}',
        'TextOverlay.detail')
    src = replace_once(src,
        'function DetailCard({ card }: { card: MockCard }) {',
        'function DetailCard({ card, onClose }: { card: MockCard; onClose: () => void }) {',
        'TextOverlay.detailFunction')
    src = replace_once(src,
        '    <div className="detail-card">',
        '    <div className="detail-card">\n'
        '      {/* [P1-UX] 触屏与键盘用户可见的关闭入口，不依赖探针。 */}\n'
        '      <button type="button" className="detail-card__close" onClick={onClose} aria-label="关闭卡牌详情">×</button>',
        'TextOverlay.closeButton')
    return src


def patch_app(src: str) -> str:
    src = replace_once(src,
        '  const [scene, setScene] = useState<MockScene>(() => initialScene());',
        """  const [scene, setScene] = useState<MockScene>(() => {
    const base = initialScene();
    // [P1-LAYOUT] ?debug&enemies=N 下制造 1~6 敌人的测试局面，默认不改变游戏。
    const query = new URLSearchParams(window.location.search);
    const raw = query.get("enemies");
    if (!query.has("debug") || raw === null) return base;
    const count = Number(raw);
    if (!Number.isInteger(count) || count < 1 || count > 6) return base;
    return {
      ...base,
      enemies: Array.from({ length: count }, (_, i) => ({
        ...base.enemies[i % base.enemies.length], slot: i,
        id: `debug_enemy_${i}`, name: `演示敌人 ${i + 1}`,
        hp: 25 + i * 4, maxHp: 25 + i * 4, intent: `攻击 ${6 + i}`,
      })),
    };
  });""", 'App.mock.debugFormation')
    src = replace_once(src,
        'import { layout } from "./stage/layout";',
        'import { layout } from "./stage/layout";\n'
        'import { enemyAtScreen, cardAtScreen } from "./input/hitTest";',
        'App.import')
    src = replace_once(src,
        '''  const [detailSlot, setDetailSlot] = useState(-1);
  const commits''',
        '''  const [detailSlot, setDetailSlot] = useState(-1);
  // [P1-UX] Hover 仅为表现层状态，不影响游戏规则与 Action 列表。
  const [hoverCardSlot, setHoverCardSlot] = useState(-1);
  const [hoveredEnemySlot, setHoveredEnemySlot] = useState(-1);
  const [notice, setNotice] = useState("");
  const [noticeKind, setNoticeKind] = useState<"success" | "warning" | null>(null);
  const activePointer = useRef<{
    id: number; type: string; startX: number; startY: number;
    longPressTimer: number | null; handSlot: number;
  } | null>(null);
  const noticeTimer = useRef<number | null>(null);
  const flash = useCallback((message: string, kind: "success" | "warning" | null = null) => {
    setNotice(message);
    setNoticeKind(kind);
    if (noticeTimer.current !== null) window.clearTimeout(noticeTimer.current);
    noticeTimer.current = window.setTimeout(() => { setNotice(""); setNoticeKind(null); }, 850);
  }, []);
  const commits''', 'App.feedback.state')
    src = replace_once(src,
        '''  // 状态机 → 副作用（提交/回弹）。**只在结果变化时触发一次**，所以用一个 ref 记住上一条结果.
''',
        '''  // 状态机 → 副作用。事件同内容不代表同事件，按 resultSeq 去重。
''', 'App.effect.comment') if False else src
    src = replace_once(src,
        '''  // 状态机 → 副作用（提交/回弹）。**只在结果变化时触发一次**，所以用一个 ref 记住上一条结果。
  const lastResultRef = useRef<string>("");''',
        '''  // [P1-UX] 相同卡牌 + 相同目标可以连续出两次：必须按事件序号而非 JSON 载荷去重。
  const lastResultSeq = useRef(0);''', 'App.effect.start')
    src = replace_once(src,
        '''    const key = JSON.stringify(result);
    if (key === lastResultRef.current) return;
    lastResultRef.current = key;''',
        '''    if (state.resultSeq === lastResultSeq.current) return;
    lastResultSeq.current = state.resultSeq;''', 'App.effect.seq')
    src = replace_once(src,
        '''      setDetailSlot(-1);
    } else {
      rebounds.current.push(result.why);
    }
  }, [state.lastResult, scene.hand, applyCommit]);''',
        '''      setDetailSlot(-1);
      flash("已出牌 · 动作已提交", "success");
    } else {
      rebounds.current.push(result.why);
      flash("已取消 · 卡牌返回手牌", "warning");
    }
  }, [state.lastResult, state.resultSeq, scene.hand, applyCommit, flash]);''', 'App.effect.end')
    src = replace_once(src,
        '''  const onCardDown = useCallback(
    (slot: number) => {
      if (modalOpen) return; // 模态打开 ⇒ 输入隔离（闸门 25 会证明它）
      const card = scene.hand[slot];
      if (!card) return;
      store.send({ type: "down", handSlot: slot, options: optionsFor(card, scene, slot) });
    },
    [modalOpen, scene, store]
  );''',
        '''  const onCardDown = useCallback(
    (slot: number, pointer: { id: number; type: string; x: number; y: number }) => {
      if (modalOpen) return;
      if (activePointer.current) return; // [P1-UX] 第一指针独占，第二根手指不可偷走当前牌。
      const card = scene.hand[slot];
      if (!card) return;
      setDetailSlot(-1);
      setHoverCardSlot(-1);
      const gesture = {
        id: pointer.id, type: pointer.type, startX: pointer.x, startY: pointer.y,
        longPressTimer: null as number | null, handSlot: slot,
      };
      activePointer.current = gesture;
      store.send({ type: "down", handSlot: slot, options: optionsFor(card, scene, slot) });
      if (pointer.type === "touch" || pointer.type === "pen") {
        // [P1-UX] 450ms 长按展示详情；移动超过拖拽阈值即取消定时器。
        // detail 与 commit 互斥：先 dismiss 状态机，再展示详情，松手不会误出牌。
        gesture.longPressTimer = window.setTimeout(() => {
          if (activePointer.current !== gesture) return;
          activePointer.current = null;
          store.send({ type: "dismiss" });
          setDetailSlot(slot);
          flash("卡牌详情 · 点击关闭按钮或按 Esc");
        }, 450);
      }
    },
    [modalOpen, scene, store, flash]
  );''', 'App.onCardDown')
    src = replace_once(src,
        '''  const onHover = useCallback(
    (slot: number) => {
      if (modalOpen) return;
      hoverRef.current = slot;
      const current = store.peek();
      if (current.phase === "idle") return;
      store.send({ type: "move", hoverSlot: slot, distance: 999 });
    },
    [modalOpen, store]
  );''',
        '''  const onHover = useCallback(
    (slot: number) => {
      if (modalOpen) return;
      hoverRef.current = slot;
      setHoveredEnemySlot((previous) => previous === slot ? previous : slot);
      // [P1-UX] 有活动手指时由 window.pointermove 统一计算真实距离，避免 R3F 事件使用 999px 假距离。
      if (activePointer.current) return;
      const current = store.peek();
      if (current.phase === "targeting") store.send({ type: "move", hoverSlot: slot, distance: 999 });
    },
    [modalOpen, store]
  );''', 'App.onHover')
    src = replace_once(src,
        '''      const current = store.peek();
      if (current.phase === "idle") return;
      store.send({ type: "up", hoverSlot: slot, distance: 999 });''',
        '''      // [P1-UX] 有活动指针时 window.pointerup 会完成事务；阻止 R3F 与 window 双提交。
      if (activePointer.current) return;
      const current = store.peek();
      if (current.phase === "idle") return;
      store.send({ type: "up", hoverSlot: slot, distance: 999 });''', 'App.onRelease')
    old='''  // 点按语义：抬起在空白处（R3F 没给我们 onPointerUp）时，用上一次 hover 兜底。
  useEffect(() => {
    const onUp = () => {
      const current = store.peek();
      if (current.phase === "pressed") {
        store.send({ type: "up", hoverSlot: -1, distance: 0 });
      } else if (current.phase === "targeting" || current.phase === "dragging") {
        store.send({ type: "up", hoverSlot: hoverRef.current, distance: 999 });
      }
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        if (modalOpen) setModalOpen(false);
        else store.send({ type: "cancel" });
      }
    };
    window.addEventListener("pointerup", onUp);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("keydown", onKey);
    };
  }, [store, modalOpen]);'''
    new='''  // [P1-UX] 全局指针跟踪：即使松开时已经离开 WebGL mesh，动作仍能完成或被正确取消。
  useEffect(() => {
    const clearPointer = () => {
      const p = activePointer.current;
      if (p?.longPressTimer !== null && p?.longPressTimer !== undefined)
        window.clearTimeout(p.longPressTimer);
      activePointer.current = null;
    };
    const currentTarget = (x: number, y: number) => {
      // [P1-UX] 命中范围由 Stage 的屏幕投影提供；不要复制三维队形公式。
      const legal = new Set(store.peek().options.filter((o) => o.slot >= 0).map((o) => o.slot));
      return enemyAtScreen(layout.enemies, x, y, legal);
    };
    const onMove = (event: PointerEvent) => {
      const p = activePointer.current;
      if (!p || p.id !== event.pointerId || modalOpen) return;
      const distance = Math.hypot(event.clientX - p.startX, event.clientY - p.startY);
      if (distance >= 8 && p.longPressTimer !== null) {
        window.clearTimeout(p.longPressTimer);
        p.longPressTimer = null;
      }
      const target = currentTarget(event.clientX, event.clientY);
      hoverRef.current = target;
      store.send({ type: "move", hoverSlot: target, distance });
    };
    const onUp = (event: PointerEvent) => {
      if (modalOpen) return;
      const p = activePointer.current;
      if (p && p.id !== event.pointerId) return;
      if (p) clearPointer();
      const current = store.peek();
      if (current.phase === "idle") return; // 长按详情已经 dismiss，不得在松手时出牌。
      const target = currentTarget(event.clientX, event.clientY);
      const distance = p ? Math.hypot(event.clientX - p.startX, event.clientY - p.startY) : 999;
      // [P1-UX] 极快拖动可能没有中间 move 事件，抬起前补一次真实距离判定。
      if (current.phase === "pressed" && distance >= 8)
        store.send({ type: "move", hoverSlot: target, distance });
      store.send({ type: "up", hoverSlot: target, distance });
    };
    const cancel = () => {
      clearPointer();
      setHoveredEnemySlot(-1);
      if (store.peek().phase !== "idle") store.send({ type: "cancel" });
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        if (modalOpen) setModalOpen(false);
        else if (detailSlot >= 0) setDetailSlot(-1);
        else cancel();
      }
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerup", onUp);
    // 第二指针取消不能把第一指针的卡牌操作误撤销。
    const onCancel = (event: PointerEvent) => {
      if (activePointer.current && event.pointerId !== activePointer.current.id) return;
      cancel();
    };
    window.addEventListener("pointercancel", onCancel);
    window.addEventListener("blur", cancel);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onCancel);
      window.removeEventListener("blur", cancel);
      window.removeEventListener("keydown", onKey);
    };
  }, [store, modalOpen, detailSlot]);
  useEffect(() => () => {
    if (activePointer.current?.longPressTimer != null) window.clearTimeout(activePointer.current.longPressTimer);
    if (noticeTimer.current !== null) window.clearTimeout(noticeTimer.current);
  }, []);'''
    src = replace_once(src, old, new, 'App.global.pointer')
    src = replace_once(src,
        '''        <Stage
          scene={scene}
          liftedSlot={liftedSlot}
          hoverSlot={state.hoverSlot}
          onCardDown={onCardDown}
          onHover={onHover}
          onRelease={onRelease}
        />''',
        '''        <Stage
          scene={scene}
          liftedSlot={liftedSlot}
          hoverSlot={state.hoverSlot}
          hoverCardSlot={hoverCardSlot}
          hoveredEnemySlot={hoveredEnemySlot}
          phase={state.phase}
          followPointer={activePointer.current !== null && state.phase !== "idle"}
          legalTargets={state.options.filter((o) => o.slot >= 0).map((o) => o.slot)}
          onCardDown={onCardDown}
          onCardHover={setHoverCardSlot}
          onHover={onHover}
          onRelease={onRelease}
        />''', 'App.Stage.props')
    src = replace_once(src,
        '''        onCreated={({ camera }) => camera.lookAt(0, 0.1, 0)}''',
        '''        onCreated={({ camera }) => camera.lookAt(0, 0.1, 0)}
        // [P1-UX] 桌面右键详情，使用命中布局投影，避免 DOM 覆盖层拦截 3D 射线。
        onContextMenu={(event) => {
          event.preventDefault();
          const slot = cardAtScreen(layout.cards, event.clientX, event.clientY);
          if (slot >= 0 && !modalOpen) {
            store.send({ type: "dismiss" });
            onDetail(slot);
          }
        }}
        style={{ cursor: activePointer.current ? "grabbing" : hoverCardSlot >= 0 ? "grab" : "default" }}''', 'App.Canvas.extra')
    src = replace_once(src,
        '''      <TextOverlay scene={scene} liftedSlot={liftedSlot} detailSlot={detailSlot} modalOpen={modalOpen} />''',
        '''      <TextOverlay scene={scene} liftedSlot={liftedSlot} hoverCardSlot={hoverCardSlot}
        detailSlot={detailSlot} modalOpen={modalOpen} onCloseDetail={() => setDetailSlot(-1)} />
      {/* [P1-UX] 文本反馈与颜色高亮并行：色弱/触屏用户也能理解当前目标状态。 */}
      {!modalOpen && (
        <div className={`gesture-hint${noticeKind ? ` is-${noticeKind}` : ""}`} role="status" aria-live="polite">
          {notice || (detailSlot >= 0 ? "卡牌详情 · 点击关闭按钮或按 Esc" :
            state.phase === "targeting" && hoveredEnemySlot >= 0 &&
              !state.options.some((o) => o.slot === hoveredEnemySlot) ?
              "红圈表示无效目标 · 选择蓝圈敌人" :
            state.phase === "targeting" ? "选择右侧高亮敌人 · 拖动或点按 · Esc 取消" :
            state.phase === "dragging" ? "松开使用卡牌 · 移到空白可撤销目标" :
            state.phase === "pressed" ? "拖动出牌 · 触屏长按看详情" :
            hoverCardSlot >= 0 ? "左键选牌或拖动 · 右键查看详情" :
            "左侧为我方，右侧为敌人 · 点击或拖动手牌")}
        </div>
      )}''', 'App.TextOverlay.extra')
    return src


def patch_css(src: str) -> str:
    return src + '''
/* ── P1-UX 示例：反馈只属于渲染层，不参与 WASM Action 判定 ─────────────── */
.card-text.is-hovered {
  /* 文字仍由 Stage 投影驱动，hover 只做清晰而克制的明度反馈。 */
  filter: drop-shadow(0 0 8px rgba(145, 205, 255, 0.5));
}
.gesture-hint {
  position: absolute;
  top: calc(env(safe-area-inset-top, 0px) + 14px);
  left: 50%;
  transform: translateX(-50%);
  max-width: min(94vw, 680px);
  z-index: 9;
  pointer-events: none; /* 提示不阻断射线；modal 才允许截获点击 */
  border: 1px solid rgba(137, 187, 232, 0.40);
  border-radius: 999px;
  padding: 7px 14px;
  background: rgba(8, 17, 27, 0.82);
  color: #dceeff;
  text-align: center;
  font-size: 12px;
  line-height: 1.5;
}
/* 操作结果颜色具有可读文字冗余，不能只靠红绿判断成功/失败。 */
.gesture-hint.is-success { border-color: rgba(120, 235, 177, 0.88); background: rgba(8, 52, 35, 0.92); }
.gesture-hint.is-warning { border-color: rgba(255, 153, 129, 0.88); background: rgba(69, 30, 23, 0.92); }
/* 详情层的父级 pointer-events:none；只有关闭按钮吃事件。 */
.detail-card__close {
  position: absolute;
  top: 8px;
  right: 8px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  border: 1px solid rgba(177, 204, 236, 0.48);
  background: #263a4e;
  color: #fff;
  font-size: 22px;
  pointer-events: auto;
  cursor: pointer;
}
.detail-card__close:focus-visible { outline: 3px solid #8fc7ff; outline-offset: 2px; }
@media (max-width: 600px) {
  .gesture-hint { font-size: 11px; padding: 5px 10px; }
}
@media (prefers-reduced-motion: reduce) {
  .gesture-hint { transition: none; }
}
'''


def run() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo', type=Path, help='path to RogueRust checkout')
    parser.add_argument('--apply', action='store_true', help='actually write files (default: safe dry-run)')
    args = parser.parse_args()
    root = args.repo.resolve()
    paths = {
        'input/pointerMachine.ts': patch_pointer,
        'stage/Stage.tsx': patch_stage,
        'overlay/TextOverlay.tsx': patch_overlay,
        'App.tsx': patch_app,
        'styles.css': patch_css,
    }
    staged: dict[Path, str] = {}
    summaries: list[tuple[str, int, int]] = []
    # **Preflight all files first**. One mismatch aborts the entire operation.
    for rel, fn in paths.items():
        p = root / TARGET / rel
        old = p.read_text(encoding='utf-8')
        new = fn(old)
        staged[p] = new
        summaries.append((rel, len(old), len(new)))
    for rel in ['stage/formation.ts', 'input/hitTest.ts']:
        p = root / TARGET / rel
        if p.exists():
            raise FileExistsError(f'{p} exists; refusing to overwrite a user implementation')
        staged[p] = (HERE / 'files' / Path(rel).name).read_text(encoding='utf-8')
    print('PREFLIGHT OK: all source anchors found; no existing new files overwritten.')
    for rel, before, after in summaries:
        print(f'  {rel}: {before} -> {after} characters')
    print('  + stage/formation.ts, input/hitTest.ts')
    if not args.apply:
        print('DRY RUN ONLY. To write: python apply_p1_ui_example.py /path/to/RogueRust --apply')
        return
    # Atomic replace of each file after preflight (no path changes outside web-next/src).
    for path, content in staged.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_name(path.name + '.ui-example-tmp')
        temp.write_text(content, encoding='utf-8')
        temp.replace(path)
    print('Applied. Run npm build and browser tests; see README for limitations.')

if __name__ == '__main__':
    try:
        run()
    except Exception as ex:
        print(f'ERROR: {ex}', file=sys.stderr)
        raise SystemExit(2)
